/***********************************************************
 CSCI 480 - Assignment 7 - Fall 2019
 
 Progammer: Sam Piecz
 Z-ID: Z1732715
 Section: 2 
 TA: Jingwan Li  
 Date Due: Dec 02, 2019 
 Purpose: FAT-12 Simulation. 
 ************************************************************/
#include "Entry.h"
#include <iostream>
#include <string>

using std::cout;
using std::endl;
using std::string;
using std::to_string;

Entry::Entry()
{
}

